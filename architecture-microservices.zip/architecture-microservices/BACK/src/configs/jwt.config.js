module.exports = {
	secret:"supersecret"
}