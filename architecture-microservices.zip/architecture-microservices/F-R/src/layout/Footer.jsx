import React from 'react';

export default class Footer extends React.Component {
	render() {
		return (
			<footer> Ceci est un Footer </footer>
		);
	}
}
